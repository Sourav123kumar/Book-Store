﻿namespace BookShoppingCartMvcUI.Constants;

public enum PaymentMethods
{
    COD=1,
    Online
}
